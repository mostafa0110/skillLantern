---
type: demo-readme
status: local-tested-sample
created: 2026-11-09
updated: 2026-11-09
tags: [demo, motion, synthetic]
---

# Motion Design — local demo pack

Open `sample/index.html`, `baseline/index.html`, and `with-skill/index.html` in a browser.
They run locally. No reservation is sent or stored. The card, names and workshop are synthetic.

This pack contains the original starting page, one normal-agent result, one skill-assisted
result, the exact shared task brief, and the reviewed LottieFiles source snapshot with its
licence. Both generated results passed our declared browser checks in one paired trial.
No comparative advantage or tier is established. There were no human participant tests.

To reproduce: keep the starting file unchanged, open a fresh coding-agent context, supply
`task.md` and ask for a new output folder. The skill condition also reads the local
`source/skills/motion-design/SKILL.md` and relevant local references. The baseline omits that
additional source. Use the same agent/model and starting inputs for both conditions.

Respect the task's local-only and accessibility requirements. Do not execute upstream install
commands or load remote README assets. This method tests explicitly loaded text context, not
native installation/automatic activation. Existing agent access is required; its costs and
allowances are separate from the MIT-licensed skill.

Check keyboard entry, blank-name validation, success, simulated error and retry, narrow layout
and reduced motion. Keep any failed output in your results. Successful local output does not
prove security or general reliability.

Source: LottieFiles/motion-design-skill at commit
`f9a8a041b85185ee4881b3471d3415e939aac772`.
The original MIT notice is preserved in `source/LICENSE`.
`source-manifest.json` records exact paths and file hashes. A separate AI manual review covered
the snapshot; the attempted NVIDIA SkillSpector installation failed, so no scanner result exists.

This is a free local review artifact, not a published or purchasable product.
