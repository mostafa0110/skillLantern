---
type: benchmark-input
status: frozen
created: 2026-11-09
updated: 2026-11-09
tags: [pilot, synthetic]
---

# Task: purposeful feedback for a practice reservation

Improve the motion and interaction feedback in the accompanying `index.html`. The result
should feel calm, responsive and clear to someone reserving a practice workshop spot.

Keep the existing content, layout purpose and form functionality. Use plain HTML/CSS/JS in
one self-contained file with no external assets, imports, dependencies, network calls, storage
or accounts. Do not execute package installers or source examples. Preserve the existing IDs,
form `data-state` values (idle/loading/success/error), and 800ms local reservation simulation.
You may improve semantics, styling and implementation while preserving that test interface.

Provide appropriate hover, press, loading, success, validation-error and retry feedback.
Keep keyboard operation and visible focus. Honour `prefers-reduced-motion`; equivalent
information must remain available without movement. Avoid distracting persistent decorative
motion, layout movement that harms interaction, or feedback conveyed only by animation.
Keep a usable narrow mobile layout. State the motion choices and any limitations briefly.

Produce `index.html` and `notes.json` in the assigned output folder. The notes fields are
`motion_intent`, `changes`, `checks_performed`, `known_limits`, and `sources_used`.
Do not invent checks: source inspection is not browser execution. Do not read other experiment
outputs or change the input files. Use only your assigned starting file, this brief and any
explicitly supplied condition-specific reference material.
